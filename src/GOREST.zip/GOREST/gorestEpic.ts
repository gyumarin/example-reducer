import {Action} from 'redux';
import {
  ActionsObservable,
  combineEpics,
  ofType,
  StateObservable,
} from 'redux-observable';
import {Observable, of} from 'rxjs';
import {getGorestEpicAction, getGorestEpicToSuccessAction} from './gorestSlice';
import {payloadSomeTypes} from '../New/types';
import {mergeMap, map, catchError} from 'rxjs/operators';

class ExampleEpicClass {
  //메서드
  exampleTimer(data: payloadSomeTypes) {
    return new Observable(subscriber => {
      this.timer(subscriber, data);
    });
  }

  //메서드
  timer(subscriber, data) {
    return new Promise(() => {
      /**
       * 여기에 수행할 비동기 함수 작성
       */
      fetch('https://gorest.co.in/public/v1/users').then(res => {
        res.json().then(result => {
          console.log(result);
          subscriber.next({
            gorest: result,
          });
        });
      });
    });
  }
}

const exampleClass = new ExampleEpicClass();

const exampleProcessActionEpic = (
  action$: ActionsObservable<Action>,
  state$: StateObservable<any>,
): Observable<Action> => {
  return action$.pipe(
    ofType(getGorestEpicAction),
    mergeMap((action: any) =>
      exampleClass.exampleTimer(action.payload).pipe(
        map((result: any) => {
          return getGorestEpicToSuccessAction({
            gorest: result.gorest,
          });
        }),
      ),
    ),
  );
};

export const gorestEpic = combineEpics(exampleProcessActionEpic);

//combine : 합치다.
