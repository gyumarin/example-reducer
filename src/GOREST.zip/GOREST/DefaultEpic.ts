import {Action} from 'redux';
import {
  ActionsObservable,
  combineEpics,
  ofType,
  StateObservable,
} from 'redux-observable';
import {Observable, of} from 'rxjs';
import {getGorestEpicAction, getGorestEpicToSuccessAction} from './gorestSlice';
import {payloadSomeTypes} from '../New/types';
import {mergeMap, map, catchError} from 'rxjs/operators';

class ExampleEpicClass {
  //메서드
  exampleTimer(data: payloadSomeTypes) {
    // Observable : 시간의 흐름에 따라 발생하는 이벤트들의 집합.
    return new Observable(subscriber => {
      //https://min9nim.vercel.app/2020-04-24-rxjs/
      this.timer(subscriber, data);
    });
  }

  //메서드
  timer(subscriber, data) {
    return new Promise(() => {
      /**
       * 여기에 수행할 비동기 함수 작성
       *
       *
       */
    });
  }
}

const exampleClass = new ExampleEpicClass();

//https://pks2974.medium.com/redux-observable-%EA%B0%84%EB%8B%A8-%EC%A0%95%EB%A6%AC-%ED%95%98%EA%B8%B0-68f331b10ef8
const exampleProcessActionEpic = (
  action$: ActionsObservable<Action>,
  state$: StateObservable<any>,
): Observable<Action> => {
  return action$.pipe(
    ofType(getGorestEpicAction),
    mergeMap((action: any) =>
      exampleClass.exampleTimer(action.payload).pipe(
        map((result: any) => {
          return getGorestEpicToSuccessAction({
            gorest: result.gorest,
          });
        }),
      ),
    ),
  );
};

const DefaultActionEpic = (action$, state$) => {
  return action$.pipe(
    ofType(getGorestEpicAction),
    mergeMap((action: any) =>
      exampleClass.exampleTimer(action.payload).pipe(
        map((result: any) => {
          return getGorestEpicToSuccessAction({
            gorest: result.gorest,
          });
        }),
      ),
    ),
  );
};

export const gorestEpic = combineEpics(exampleProcessActionEpic);

//combine : 합치다.
